package morphalou;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

import util.FileIO;

import java.io.File;

public class MorphalouReader {

	public static void main(String[] args) {
	    try {
	    	StringBuffer writer = new StringBuffer();
	    	File fXmlFile = new File("Morphalou-2.0.xml");
	    	DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	    	DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	    	Document doc = dBuilder.parse(fXmlFile);
	     
	    	//optional, but recommended
	    	//read this - http://stackoverflow.com/questions/13786607/normalization-in-dom-parsing-with-java-how-does-it-work
	    	doc.getDocumentElement().normalize();
	     
	    	System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
	     
	    	NodeList nList = doc.getElementsByTagName("lexicalEntry");
	     
	    	System.out.println("----------------------------");
	     
	    	for (int temp = 0; temp < nList.getLength(); temp++) {
	     
	    		Node nNode = nList.item(temp);
	     
	    		System.out.println("\nCurrent Element :" + nNode.getNodeName());
	     
	    		if (nNode.getNodeType() == Node.ELEMENT_NODE) {
	     
	    			Element eElement = (Element) nNode;
	    			String lemmatizedForm = "NONE";
	    			String orthography = "NONE";
	    			String grammaticalCategory = "NONE";
	    			String grammaticalGender = "NONE";
	    			String grammaticalNumber = "NONE";
	    			String feminineVariantOf = "NONE";
	    			String spellingVariantOf = "NONE";
	     
	    			System.out.println("lexicalEntry id : " + eElement.getAttribute("id"));
	    			System.out.println("formSet : " + eElement.getElementsByTagName("formSet").item(0).getNodeName());
	    			
	    			if(eElement.getElementsByTagName("feminineVariantOf").getLength()>0){
	    				feminineVariantOf = eElement.getElementsByTagName("feminineVariantOf").item(0).getTextContent().toLowerCase().trim();
	    			}
	    			if(eElement.getElementsByTagName("spellingVariantOf").getLength()>0){
	    				spellingVariantOf = eElement.getElementsByTagName("spellingVariantOf").item(0).getTextContent().toLowerCase().trim();
	    			}
	    			
	    			NodeList node = eElement.getElementsByTagName("formSet").item(0).getChildNodes();
	    			
	    			for(int i = 0 ; i < node.getLength() ; i++){
	    				if(node.item(i).getNodeType() == Node.ELEMENT_NODE){
	    					Element element = (Element)node.item(i);
		    				if(element.getNodeName().equalsIgnoreCase("lemmatizedForm")){
		    					if(element.getElementsByTagName("orthography").getLength()>0){
		    						System.out.println("orthography "+element.getElementsByTagName("orthography").item(0).getTextContent());
		    						lemmatizedForm = element.getElementsByTagName("orthography").item(0).getTextContent().toLowerCase().trim();
		    					}
		    					if(element.getElementsByTagName("grammaticalCategory").getLength()>0){
		    						System.out.println("grammaticalCategory "+element.getElementsByTagName("grammaticalCategory").item(0).getTextContent());
		    						grammaticalCategory = element.getElementsByTagName("grammaticalCategory").item(0).getTextContent().trim();
		    					}
		    					if(element.getElementsByTagName("grammaticalGender").getLength()>0){
		    						
		    						System.out.println("grammaticalGender "+element.getElementsByTagName("grammaticalGender").item(0).getTextContent());
		    						grammaticalGender = element.getElementsByTagName("grammaticalGender").item(0).getTextContent().trim();
		    					}
		    					
		    					//writer.append(lemmatizedForm+"\t"+grammaticalGender+"\t"+grammaticalNumber+"\t"+grammaticalCategory+"\t"+lemmatizedForm+"\n");
		    				}
		    				if(element.getNodeName().equalsIgnoreCase("inflectedForm")){
		    					if(element.getElementsByTagName("orthography").getLength()>0){
		    						System.out.println("orthography "+element.getElementsByTagName("orthography").item(0).getTextContent());
		    						orthography = element.getElementsByTagName("orthography").item(0).getTextContent().toLowerCase().trim();
		    					
		    					}
		    					if(element.getElementsByTagName("grammaticalNumber").getLength()>0){
		    						System.out.println("grammaticalNumber "+element.getElementsByTagName("grammaticalNumber").item(0).getTextContent());
		    						grammaticalNumber = element.getElementsByTagName("grammaticalNumber").item(0).getTextContent().trim();
		    					}
		    					writer.append(orthography+"\t"+grammaticalGender+"\t"+grammaticalNumber+"\t"+grammaticalCategory+"\t"+lemmatizedForm+"\n");
		    					if(!feminineVariantOf.equals("NONE")){
		    						writer.append(orthography+"\t"+grammaticalGender+"\t"+grammaticalNumber+"\t"+grammaticalCategory+"\t"+feminineVariantOf+"\n");
		    					}
		    					
		    					if(!spellingVariantOf.equals("NONE")){
		    						writer.append(orthography+"\t"+grammaticalGender+"\t"+grammaticalNumber+"\t"+grammaticalCategory+"\t"+spellingVariantOf+"\n");
		    					}
		    				}
	    				}
	    					    				
	    			}
	    			
	    			if(eElement.getElementsByTagName("feminineVariantOf").getLength()>0){
	    				System.out.println("feminineVariantOf : " + eElement.getElementsByTagName("feminineVariantOf").item(0).getTextContent());
	    				orthography = lemmatizedForm;
	    				lemmatizedForm = eElement.getElementsByTagName("feminineVariantOf").item(0).getTextContent().toLowerCase().trim(); 
	    				writer.append(orthography+"\t"+grammaticalGender+"\t"+grammaticalNumber+"\t"+grammaticalCategory+"\t"+lemmatizedForm+"\n");
	    			}
	    			if(eElement.getElementsByTagName("spellingVariantOf").getLength()>0){
	    				orthography = lemmatizedForm;
	    				lemmatizedForm = eElement.getElementsByTagName("spellingVariantOf").item(0).getTextContent().toLowerCase().trim(); 
	    				System.out.println("spellingVariantOf : " + eElement.getElementsByTagName("spellingVariantOf").item(0).getTextContent());
	    				writer.append(orthography+"\t"+grammaticalGender+"\t"+grammaticalNumber+"\t"+grammaticalCategory+"\t"+lemmatizedForm+"\n");
	    			}
	    			
	    			
	     
	    		}
	    	}
	    	
	    	FileIO.writeFile(writer.toString(), "d:\\morphalou.txt", "UTF-8");
	        } catch (Exception e) {
	    	e.printStackTrace();
	        }

	}

}
