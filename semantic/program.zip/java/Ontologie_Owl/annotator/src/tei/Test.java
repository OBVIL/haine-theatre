package tei;

public class Test {
	
	public static void main(String [] args){
		String text = "bonjour tout le p�re et m�re �uvre";
		 
		char[] chars = text.toCharArray();
		for(char e : chars){
			System.out.println(e);
		}
	}

}
