package ir;

public class FormData {
	
	private String formText = "";
	private String grammaticalGender = "NONE";
	private String number = "NONE";
	
	public FormData(){
		
	}
		
	

	public FormData(String formText, String grammaticalGender, String number) {
		super();
		this.formText = formText;
		this.grammaticalGender = grammaticalGender;
		this.number = number;
	}



	public String getFormText() {
		return formText;
	}
	public void setFormText(String formText) {
		this.formText = formText;
	}
	public String getGrammaticalGender() {
		return grammaticalGender;
	}
	public void setGrammaticalGender(String grammaticalGender) {
		this.grammaticalGender = grammaticalGender;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}
	
	
	
	

}
