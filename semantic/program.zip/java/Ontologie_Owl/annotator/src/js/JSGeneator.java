package js;

import java.io.File;
import java.util.List;

import owl.OntologyManager;
import util.FileIO;
import util.Parameters;

public class JSGeneator {
	
	private static String VAR_DECLARATIONS = "$VAR_DECLARATIONS";
	private static String COLORS [] = {"#006600", "#00CC00", "#336666", "#009999", "#CC0066",
		"#3300FF", "#330099", "#333366", "#663300", "#CC0000", "#000033", "#006666", "#0066CC", 
		"#0066FF", "#0060FF","#0050FE","#0030FE", "#009900", "#E6E2AF","#A7A37E",
		"#046380","#002F2F","#B4AF91","#787746","#40411E","#32331D","#C03000","#B9121B",
		"#4C1B1B","#F6E497","#BD8D46","#333333","#FF358B","#01B0F0","#AEEE00",
		"#ADCF4F","#84815B","#4A1A2C","#8E3557","#96CA2D","#B5E655",
		"#4BB5C1","#7FC6BC","#4072A4","#40A49E","#A4406B","#A41452","#840A89","#753519",
		"#867872","#414C4F"};

	public static void GENERATE_JS_SCRIPT(){
		System.err.println("Generation semantic.js script from ontology categories...");
		List<String> categories = OntologyManager.getCategories();
		//System.out.println(categories.size());
		int size = COLORS.length;
		StringBuffer declarations = new StringBuffer();
		int i = 0;
		for(String category : categories){
			String color = COLORS[i];
			//System.out.println(category);
			
			String script = "semanticFieldLabel['"+category+"'] = \"<b>"+category+"</b>\";\n";
			script = script + "semanticFieldColors['"+category+"'] = \""+color+"\";\n";
			script = script + "semanticFieldInstance['"+category+"'] =  new Array();\n";
			script = script + "semanticFieldStatistics['"+category+"'] =  0;\n";
			script = script + "semanticFieldAllInstance['"+category+"'] =  new Array();\n";
			
			declarations.append(script);
			declarations.append("\n");
			i++;
			if(i >= size){
				i = 0;
			}
			
		}
		
		String jsFile = FileIO.readFile(new File(Parameters.GET_JS_MODEL_PATH()), Parameters.UTF8);
		jsFile = jsFile.replace(VAR_DECLARATIONS, declarations.toString());
		
		FileIO.writeFile(jsFile, Parameters.GET_JS_RESULT_MODEL_PATH(), Parameters.UTF8);
	}

	public static void main(String[] args) {
		
		JSGeneator.GENERATE_JS_SCRIPT();
		
		

	}

}
