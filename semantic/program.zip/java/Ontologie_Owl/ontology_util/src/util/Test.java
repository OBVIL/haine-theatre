package util;

import java.util.ArrayList;

public class Test {

	public static void main(String[] args) {
		ArrayList<String> test = new ArrayList<String>();
		test.set(0, "bonjour");
		System.out.println(test);

	}

}
